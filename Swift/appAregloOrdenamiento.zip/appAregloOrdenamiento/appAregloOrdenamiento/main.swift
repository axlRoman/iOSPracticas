//
//  main.swift
//  appAregloOrdenamiento
//
//  Created by Axel Roman on 03/05/24.
//

import Foundation

func burbuja(arrayN:Array<Int>)->Array<Int>{
    var array = arrayN
    let n = array.count
    for i in 0..<n {
        for j in 0..<(n - i - 1) {
            if array[j] > array[j + 1] {
                // Swap elements
                let temp = array[j]
                array[j] = array[j + 1]
                array[j + 1] = temp
            }
        }
    }
    return array
}

var aleatorios:Int
var arrNumeros:[Int] = []

for _ in 1...10
{
    arrNumeros.append(Int.random(in: 10...100))
}

print("Array antes de ordenar: \(arrNumeros)")

arrNumeros = burbuja(arrayN: arrNumeros)

print("Array después de ordenar: \(arrNumeros)")
        
//opcion para asignar con idexador

//arrNumeros[]

//ORDENAR LOS DATOS CON LA BURBUJA


