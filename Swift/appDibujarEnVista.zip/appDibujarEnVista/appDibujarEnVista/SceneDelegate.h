//
//  SceneDelegate.h
//  appDibujarEnVista
//
//  Created by Axel Roman on 13/05/24.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

