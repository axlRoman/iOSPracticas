//
//  ViewController.m
//  appDibujarEnVista
//
//  Created by Axel Roman on 13/05/24.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
