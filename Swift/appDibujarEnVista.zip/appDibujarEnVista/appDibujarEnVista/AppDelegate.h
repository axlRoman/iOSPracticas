//
//  AppDelegate.h
//  appDibujarEnVista
//
//  Created by Axel Roman on 13/05/24.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

