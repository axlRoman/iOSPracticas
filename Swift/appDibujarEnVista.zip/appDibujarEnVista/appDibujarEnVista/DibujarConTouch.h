//
//  DibujarConTouch.h
//  appDibujarEnVista
//
//  Created by Axel Roman on 13/05/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DibujarConTouch : UIView

@end

NS_ASSUME_NONNULL_END
