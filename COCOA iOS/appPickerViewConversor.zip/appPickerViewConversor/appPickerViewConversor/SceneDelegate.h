//
//  SceneDelegate.h
//  appPickerViewConversor
//
//  Created by Axel Roman on 11/04/24.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

