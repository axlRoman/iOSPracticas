//
//  SceneDelegate.h
//  appCartas
//
//  Created by Axel Roman on 31/03/24.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

