//
//  PlayingCardDeck.h
//  appCartas
//
//  Created by Axel Roman on 01/04/24.
//

#import "Deck.h"

NS_ASSUME_NONNULL_BEGIN

@interface PlayingCardDeck : Deck

@end

NS_ASSUME_NONNULL_END
