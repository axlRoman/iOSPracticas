//
//  AppDelegate.h
//  appIOS1
//
//  Created by Axel Roman on 20/03/24.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

