//
//  AppDelegate.h
//  appJuegoPalabras
//
//  Created by Axel Roman on 18/03/24.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

