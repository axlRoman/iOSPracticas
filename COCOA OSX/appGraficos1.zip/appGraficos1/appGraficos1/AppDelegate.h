//
//  AppDelegate.h
//  appGraficos1
//
//  Created by Axel Roman on 15/03/24.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

