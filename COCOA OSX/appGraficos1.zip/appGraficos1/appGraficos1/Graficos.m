//
//  Graficos.m
//  appGraficos1
//
//  Created by Axel Roman on 15/03/24.
//

#import "Graficos.h"

@implementation Graficos

-(NSPoint) puntosAleatorios
{
    NSPoint result;
    NSRect rec = [self bounds];
    result.x = rec.origin.x + random() % (int) rec.size.width;
    result.y = rec.origin.y + random() % (int) rec.size.height;
    return result;
    
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
    
    NSRect rectangulo = [self bounds];
    [[NSColor brownColor] set];
    
    [NSBezierPath fillRect:rectangulo];//PINTAMOS EL RECTANGULO
    
    [[NSColor whiteColor]set];
    
    srandom((unsigned)time(NULL));
    NSBezierPath *path = [[NSBezierPath alloc] init];
    [path setLineWidth:3.0];
    NSPoint p = [self puntosAleatorios];
    [path moveToPoint:p];
    for(int i = 0; i < 20;i++)
    {
        p = [self puntosAleatorios];
        [path lineToPoint:p];
    }
    
    [path stroke];// DIBUJA LAS LINEA
    //[path fill]; //RELLENO DE POLIGONOS CONVEXOS
    
    //DIBUJAR UN TRIANGULO RECTANGULO, UBICARLO EN EL ORIGEN (0,0)
}


@end
