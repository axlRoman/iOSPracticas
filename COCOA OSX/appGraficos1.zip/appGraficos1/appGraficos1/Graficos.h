//
//  Graficos.h
//  appGraficos1
//
//  Created by Axel Roman on 15/03/24.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface Graficos : NSView

- (NSPoint) puntosAleatorios;


@end

NS_ASSUME_NONNULL_END
