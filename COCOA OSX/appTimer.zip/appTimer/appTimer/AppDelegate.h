//
//  AppDelegate.h
//  appTimer
//
//  Created by Axel Roman on 12/03/24.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

