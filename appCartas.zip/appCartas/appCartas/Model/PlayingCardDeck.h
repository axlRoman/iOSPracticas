//
//  PlayingCardDeck.h
//  appCartas
//
//  Created by Axel Roman on 01/04/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PlayingCardDeck : NSObject

@end

NS_ASSUME_NONNULL_END
