//
//  Card.m
//  appCartas
//
//  Created by Axel Roman on 31/03/24.
//

#import "Card.h"

@implementation Card

@end
