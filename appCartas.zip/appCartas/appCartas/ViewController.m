//
//  ViewController.m
//  appCartas
//
//  Created by Axel Roman on 31/03/24.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *vueltasTexto;
@property (nonatomic) int flipCount;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void) setFlipCount:(int)flipCount{
    _flipCount = flipCount;
    self.vueltasTexto.text = [NSString stringWithFormat:@"Vueltas: %d",self.flipCount];
    NSLog(@"Contador de Vueltas cambio a %d", self.flipCount);
}

- (IBAction)btnCarta:(UIButton *)sender {
    //UIImage *cardImage = ;
    
    
    UIImage *frenteImage = [UIImage imageNamed:@"AS Corazon"];

    
    if ([sender.currentImage isEqual:frenteImage]) {
        [sender setImage:[UIImage imageNamed:@"atrashd"] forState:UIControlStateNormal];
    } else {
        [sender setImage:frenteImage forState:UIControlStateNormal];
    }
    [sender setTitle:@"" forState:UIControlStateNormal];
    self.flipCount++;

    
    
    
    
////    UIImage *frenteImage = [UIImage imageNamed:@"frente"];
////    [sender setImage:frente forState:UIControlStateNormal];
////
//
//    if ([sender.currentTitle length]) {
//
//        [sender setImage:[UIImage imageNamed:@"atrashd"] forState:UIControlStateNormal];
//        [sender setTitle:@"" forState:UIControlStateNormal];
//    } else {
//        [sender setImage:[UIImage imageNamed:@"AS Corazon"] forState:UIControlStateNormal];
//        [sender setTitle:@"" forState:UIControlStateNormal];
//    }
    

    
}




@end
